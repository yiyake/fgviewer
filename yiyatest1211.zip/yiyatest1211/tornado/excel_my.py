import pymysql
import xlrd
 
 
# 连接数据库
try:
    db = pymysql.connect(host="127.0.0.1", user="root",
                         passwd="KEyiya19960302",
                         db="kyy",
                         charset='utf8')
except:
    print("could not connect to mysql server")
 
 
def open_excel():
    try:
        book = xlrd.open_workbook("dbVar_vcf_info_that_have_FG.xlsx")  #文件名，把文件与py文件放在同一目录下
    except:
        print("open excel file failed!")
    try:
        sheet = book.sheet_by_name("dbVar_vcf_info_that_have_FG")   #execl里面的worksheet1
        return sheet
    except:
        print("locate worksheet in excel failed!")
 
 
def insert_deta():
    sheet = open_excel()
    cursor = db.cursor()
    row_num = sheet.nrows
    for i in range(1, row_num):  # 第一行是标题名，对应表中的字段名所以应该从第二行开始，计算机以0开始计数，所以值是1
        row_data = sheet.row_values(i)
        value = (row_data[0],row_data[1],row_data[2],row_data[3],row_data[4],row_data[5],row_data[6],row_data[7])
        print(i)
        sql = "INSERT INTO db_fgs(dbdate,Publication,Study_ID,Organism,variant_regions,variant_calls,FGs,FGBPs)VALUES(%s,%s,%s,%s,%s,%s,%s,%s)"
        cursor.execute(sql, value)  # 执行sql语句
        db.commit()
    cursor.close()  # 关闭连接
 
 
open_excel()
insert_deta()