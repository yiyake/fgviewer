#dr1_info_='808	ENST00000397938.6	chr22	+	29268017	29300525	29268336	29300161	17	29268017,29272215,29272379,29273740,29278029,29282389,29286922,29288605,29291561,29292136,29292487,29296238,29297826,29298732,29299233,29299598,29300121,	29268349,29272252,29272431,29273864,29278216,29282557,29287134,29288786,29291599,29292169,29292606,29296368,29297949,29298895,29299331,29299851,29300525,	0	EWSR1	cmpl	cmpl	0,1,2,0,1,2,2,1,2,1,1,0,1,1,2,1,2,'
#dr2_info_='195	ENST00000527786.6	chr11	+	128693769	128813267	128694258	128810988	9	128693769,128758114,128768117,128772781,128781957,128805365,128807179,128809156,128810458,	128694276,128758326,128768272,128772985,128782023,128805431,128807239,128809204,128813267,	0	FLI1	cmpl	cmpl	0,0,2,1,1,1,1,1,1,'
dr1_info_='113	ENST00000318522.9	chr2	+	42169349	42332548	42169611	42330207	23	42169349,42245504,42256500,42261120,42263177,42264705,42280849,42282822,42284633,42286268,42288226,42295124,42295380,42301240,42303103,42303314,42304483,42315961,42317426,42325466,42326153,42328885,42329733,	42169636,42245687,42256630,42261294,42263306,42264731,42280973,42282972,42284703,42286379,42288322,42295259,42295516,42301392,42303229,42303446,42304551,42316050,42317524,42325554,42326252,42329016,42332548,	0	EML4	cmpl	cmpl	0,1,1,2,2,2,1,2,2,0,0,0,0,1,0,0,0,2,1,0,1,1,0,'
dr2_info_='12	ENST00000389048.7	chr2	-	29192773	29921566	29193223	29920659	29	29192773,29196769,29197541,29207170,29209785,29213983,29220705,29222343,29222516,29223341,29225460,29226921,29227573,29228883,29232303,29233564,29239679,29251104,29275098,29275401,29296887,29318303,29320750,29328349,29383731,29531914,29694849,29717577,29919992,	29193922,29196860,29197676,29207272,29209878,29214081,29220835,29222408,29222607,29223528,29225565,29227074,29227672,29229066,29232448,29233696,29239830,29251267,29275227,29275496,29297057,29318404,29320882,29328481,29383859,29532116,29695014,29717697,29921566,	0	ALK	cmpl	cmpl	0,2,2,2,2,0,2,0,2,1,1,1,1,1,0,0,2,1,1,2,0,1,1,1,2,1,1,1,0,'

#dr1_info_='95	ENST00000359540.7	chr22	+	23180364	23315950	23180960	23315522	22	23180364,23253798,23260949,23261354,23268407,23271531,23273080,23273633,23283976,23285032,23287158,23288096,23289516,23290338,23292540,23309423,23310323,23311696,23312886,23313967,23314551,23315432,	23182239,23253980,23261054,23261540,23268515,23271592,23273133,23273774,23284098,23285201,23287278,23288172,23289621,23290413,23292638,23309483,23310433,23311836,23313021,23314073,23314714,23315950,	0	BCR	cmpl	cmpl	0,1,0,0,0,0,1,0,0,2,0,0,1,1,1,0,0,2,1,1,2,0,'
#dr2_info_='197	ENST00000372348.6	chr9	+	130713945	130885683	130714319	130885683	11	130713945,130854063,130854800,130862762,130872128,130872859,130874867,130878414,130880067,130880499,130883968,	130714455,130854237,130855096,130863035,130872213,130873037,130875052,130878567,130880157,130880664,130885683,	0	ABL1	cmpl	cmpl	0,1,1,0,0,1,2,1,1,1,1,'
dr1_info=dr1_info_.split('\t')
dr2_info=dr2_info_.split('\t')


#print dr1_info
#print dr2_info
#glist=['BCR','ABL1']
#bplist=['chr22:23182239','chr9:130854063']
#glist=['EWSR1','FLI1']
#bplist=['chr22:29287136','chr11:128807179'] # ewsr1-fli1 intron bp
glist=['EML4','ALK']
bplist=['chr2:42325554','chr2:29223528'] # eml4-alk real bp
#bplist2=['chr2:42325568','chr2:29223542'] # eml4-alk intron bp

def analORF(glist,bplist,dr1_info,dr2_info):
	ORF=''
	if glist!=[] and bplist!=[] and dr1_info!=[] and dr2_info!=[]:
		g=glist[0]
	    tg=glist[1]
	    BP=bplist[0]
	    tBP=bplist[1]
		bp=int(BP.split(':')[1])
		bp2=int(tBP.split(':')[1])
		ebp=0
		ebp2=0
		nm=dr1_info[1].split('.')[0]
        [strand=dr1_info[3]
		exs_=dr1_info[9].split(',')[:-1]
		exe_=dr1_info[10].split(',')[:-1]
                exs=[int(i) for i in exs_]
                exe=[int(i) for i in exe_]
		cds=int(dr1_info[6])
		cde=int(dr1_info[7])
		chr1=dr1_info[2]
                nm2=dr2_info[1].split('.')[0]
                strand2=dr2_info[3]
		exs2_=dr2_info[9].split(',')[:-1]
		exe2_=dr2_info[10].split(',')[:-1]
                exs2=[int(i) for i in exs2_]
                exe2=[int(i) for i in exe2_]
                cds2=int(dr2_info[6])
                cde2=int(dr2_info[7])
		chr2=dr2_info[2]
		mrnalen=0
		realbpmrna=0
		left=0
		flag5=''
		flag3=''
		lenex=len(exs)
		if strand=='+':
			#print '+ strand1'
			cdssexi=10000
			cdseexi=10000
			mrnastr=[]
			bpexon=10000 # BP at the exon junction
			bpexon_=10000 # BP in the middle of exon
			bpexon__=10000 # BP in the middle of intron
			mrnastr2=[]
			for e in range(len(exs)):
				mrnalen+=exe[e]-exs[e]
				mrnastr.append(exe[e]-exs[e])
				mrnastr2.append(mrnalen)
				if exs[e]<=cds<=exe[e]:
					cdssexi=e
				if exs[e]<=cde<=exe[e]:
					cdseexi=e

				if exe[e]<= bp and bp <=exe[e]+6:
					bpexon=e
					ebp=exe[e]
				if exs[e]< bp and bp <exe[e]:
					bpexon_=e
					ebp=bp
				if e!=0	and e!=len(exs)-1:
					if exe[e-1]+6< bp and bp<exs[e]-6:
						bpexon__=e-1
						#bpexon=e-1

			#print chr1
			#print bp
			#print exs
			#print exe
			#print 'bpexon='+str(bpexon)
			#print 'bpexon_='+str(bpexon_)
			#print 'bpexon__='+str(bpexon__)
			#print 'cdssexi='+str(cdssexi)
                        #print 'cdseexi='+str(cdseexi)

			if (cdssexi!=10000 and bpexon!=10000) or (cdssexi!=10000 and bpexon_!=10000):
				#print '>1'
				cd5=0
				if ebp < cds and exs[0]<ebp:
					flag5='5UTR'
				elif cde < ebp and ebp<exe[lenex-1]:
					flag5='3UTR'
				else:
					if bpexon!=10000:
						#print '>1_1'
						if bpexon==cdssexi:
							cd5=abs(exe[bpexon]-cds)
						elif cdssexi<bpexon:
							for a in range(bpexon-cdssexi+1):
								if a==0:
									cd5+=exe[cdssexi+a]-cds
								else:
									cd5+=exe[cdssexi+a]-exs[cdssexi+a]
					if bpexon_!=10000:
						#print '>1_2'
						if bpexon_==cdssexi:
							cd5=abs(bp-cds)
						elif cdssexi<bpexon_:
							for a in range(bpexon_-cdssexi+1):
								if a==0:
									cd5+=exe[cdssexi+a]-cds
								elif a==(bpexon_-cdssexi):
									cd5+=bp-exs[cdssexi+a]
								else:
									cd5+=exe[cdssexi+a]-exs[cdssexi+a]
					realbpmrna=cd5/3
					left=cd5%3
			else:
				flag5='intron'	

		else:
			#print '- strnad1'
			cdssexi=10000
			cdseexi=10000
			mrnastr=[]
			mrnastr2=[]
			bpexon=10000
			bpexon_=10000
			for e in range(len(exs)):
				mrnalen+=exe[lenex-e-1]-exs[lenex-e-1]
				mrnastr.append(exe[lenex-e-1]-exs[lenex-e-1])
				mrnastr2.append(mrnalen)
				if exs[lenex-e-1]<=cds<=exe[lenex-e-1]:
					cdseexi=lenex-e-1
				if exs[lenex-e-1]<=cde<=exe[lenex-e-1]:
					cdssexi=lenex-e-1

				if exs[lenex-e-1]-6<= bp and bp <=exs[lenex-e-1]:
					bpexon=e
					ebp=exs[lenex-e-1]
				if exs[lenex-e-1]< bp and bp <exe[lenex-e-1]:
					bpexon_=e
					ebp=bp
                                if e!=0 and e!=len(exs)-1:
                                        if exe[lenex-e-2]+6<bp and bp <exs[lenex-e-1]-6:
                                                bpexon__=e
						#bpexon=e

			if (cdseexi!=10000 and bpexon!=10000) or (cdseexi!=10000 and bpexon_!=10000):
				#print '>2'
				cd5=0
				if cde < ebp and ebp<exe[lenex-1]:
					flag5='5UTR'
				elif ebp < cds and exs[0]<ebp:
					flag5='3UTR'
				else:
					if bpexon!=10000:
						#print '>2_1'
						if bpexon==lenex-cdseexi:
							cd5=abs(exs[lenex-bpexon-1]-cde)
						elif cdseexi<bpexon:
							for a in range(bpexon-cdseexi+1):
								if a==0:
									cd5+=cde-exs[lenex-1]
								else:
									cd5+=exe[lenex-a-1]-exs[lenex-a-1]
					if bpexon_!=10000:
						#print '>2_2'
						if bpexon_==lenex-cdseexi:
							cd5=abs(bp-cde)
						elif cdseexi<bpexon_:
							for a in range(bpexon_-cdseexi+1):
								if a==0:
									cd5+=cde-exs[lenex-1]
                                elif a==bpexon_-cdssexi:
                                    cd5+=exe[lene-a-1]-bp
								else:
									cd5+=exe[lenex-a-1]-exs[lenex-a-1]

					realbpmrna=cd5/3
					left=cd5%3
			else:
				flag5='intron'
		
		lenex2=len(exs2)
		mrnalen2=0
		realbpmrna2=0
		right=0

		#print chr2
		#print bp2
		#print exs2
		#print exe2
		if strand2=='+':
			#print '+ strand2'
			cdssexi2=10000
			cdseexi2=10000
			mrnastr2_=[]
			bpexon2=10000
			bpexon22=10000
			bpexon222=10000
			mrnastr22_=[]
			for e2 in range(len(exs2)):

				mrnalen2+=exe2[e2]-exs2[e2]
				mrnastr2_.append(exe2[e2]-exs2[e2])
				mrnastr22_.append(mrnalen2)
				if exs2[e2]<=cds2<=exe2[e2]:
					cdssexi2=e2
				if exs2[e2]<=cde2<=exe2[e2]:
					cdseexi2=e2

				if exs2[e2]-6<=bp2 and bp2 <=exs2[e2]:
					bpexon2=e2
					ebp2=exs2[e2]
					#print '1--bpexon2='+str(bpexon2)
				if exs2[e2]<bp2 and bp2 <exe2[e2]:
					bpexon22=e2
					ebp2=bp2
					#print '2--bpexon2='+str(bpexon2)
                    if e2!=0 and e2!=len(exs2)-1:
					#print '2222'
                        if exe2[e2]+6<bp2 and bp2 <exs2[e2+1]-6:
						#print '3--bpexon2='+str(bpexon2)
                            bpexon222=e2+1
                                                #bpexon2=e2+1
						#print '3--bpexon2='+str(bpexon2)
						#print '3--bpexon222='+str(bpexon222)

                        #print 'bpexon2='+str(bpexon2)
                        #print 'bpexon22='+str(bpexon22)
                        #print 'bpexon222='+str(bpexon222)
                        #print 'cdssexi2='+str(cdssexi2)
                        #print 'cdseexi2='+str(cdseexi2)

			if (cdseexi2!=10000 and bpexon2!=10000) or (cdseexi2!=10000 and bpexon22!=10000):
				#print '>_1'

				if cde2<ebp2 and ebp2<exe2[lenex2-1]:
					flag3='3UTR'
					
				elif ebp2<cds2 and exs2[0]<ebp2:
					flag3='5UTR'
				else:
					cd3=0
					if bpexon2!=10000:
						#print '>_1_1'
						if bpexon2==cdseexi2:
							cd3=abs(exe2[bpexon2]-cde2)
						elif bpexon2<cdseexi2:
							for a in range(cdseexi2-bpexon2+1):
								if a==cdseexi2-bpexon2:
									cd3+=cde2-exs2[bpexon2+a]
								else:
									cd3+=exe2[bpexon2+a]-exs2[bpexon2+a]
					if bpexon22!=10000:
						#print '>_1_2'
						if bpexon22==cdseexi2:
							cd3=abs(bp2-cde2)
						elif bpexon22<cdseexi2:
							for a in range(cdseexi2-bpexon22+1):
								if a==cdseexi2-bpexon22:
									cd3+=cde2-exs2[bpexon22+a]
                                elif a==0:
                                    cd3+=exe2[bpexon22+a]-bp2
								else:
									cd3+=exe2[bpexon22+a]-exs2[bpexon22+a]


					realbpmrna=cd3/3
					right=cd3%3
			else:
				flag3='intron'

		else:
			#print '- strand2'
			cdssexi2=10000
			cdseexi2=10000
			mrnastr2_=[]
			mrnastr22_=[]
			bpexon2=10000
			bpexon22=10000
			bpexon222=10000
			for e2 in range(len(exs2)):
				mrnalen2+=exe2[lenex2-e2-1]-exs2[lenex2-e2-1]
				mrnastr2_.append(exe2[lenex2-e2-1]-exs2[lenex2-e2-1])
				mrnastr22_.append(mrnalen2)
				if exs2[lenex2-e2-1]<=cds2<=exe2[lenex2-e2-1]:
					cdseexi2=lenex2-e2-1
				if exs2[lenex2-e2-1]<=cde2<=exe2[lenex2-e2-1]:
					cdssexi2=lenex2-e2-1

				if exe2[lenex2-e2-1]<= bp2 and bp2 <=exe2[lenex2-e2-1]+6:
					bpexon2=e2
					ebp2=exe2[lenex2-e2-1]

				if exs2[lenex2-e2-1]< bp2 and bp2 <exe2[lenex2-e2-1]:
					bpexon22=e2
					ebp2=bp2
                                if e2!=0 and e2!=len(exs2)-1:
                                    if exe2[lenex2-e2-2]+6<bp2 and bp2 <exs2[lenex2-e2-1]-6:
                                        bpexon222=e2-1
                                                #bpexon2=e2-1

                        #print 'bpexon2='+str(bpexon2)
                        #print 'bpexon22='+str(bpexon22)
                        #print 'bpexon222='+str(bpexon222)
                        #print 'cdssexi2='+str(cdssexi2)
                        #print 'cdseexi2='+str(cdseexi2)
			#print 'lenex2='+str(lenex2)

			if (cdseexi2!=10000 and bpexon2!=10000) or (cdseexi2!=10000 and bpexon22!=10000):
				#print '>_2'
				if cde2 < ebp2 and ebp2<exe2[lenex2-1]:
					flag3='5UTR'
				elif ebp2 < cds2 and exs2[0]<ebp2:	
					flag3='3UTR'
				else:
					cd3=0
					if bpexon2!=10000:
						#print '>_2_1'
						if bpexon2==lenex2-cdseexi2-1:
							#print '--1'
							cd3=abs(exe2[bpexon2]-cds2)
						elif cdseexi2<bpexon2:

							for a in range((lenex2-bpexon2)-cdseexi2):
								if a==0:
									cd3+=exe2[cdseexi2+a]-cds2
									#print '--2'
								else:
									cd3+=exe2[cdseexi2+a]-exs2[cdseexi2+a]
									#print '--3'
					if bpexon22!=10000:
						#print '>_2_2'
						if bpexon22==lenex2-cdseexi2-1:
							cd3=exe2[bpexon22]-cds2
						elif cdseexi2<bpexon22:
							for a in range((lenex2-bpexon22)-cdseexi2):
								if a==0:
									cd3+=exe2[cdseexi2+a]-cds2
								elif a==(lenex2-bpexon22)-cdseexi2-1:
									cd3+=bp2-exs2[cdseexi2+a]
								else:
									cd3+=exe2[cdseexi2+a]-exs2[cdseexi2+a]

					realbpmrna=cd3/3
					right=cd3%3
			else:
				flag3='intron'

		#print flag5
		#print flag3
		#print left
		#print right

		orf=''
		if flag5=='' and flag3=='':
			summ=left+right
			if summ%3==0:
				orf='In-frame'
			else:
				orf='Frame-shift'
		elif flag5!='' and flag3!='':
			orf=flag5+'-'+flag3
		elif flag5=='' and flag3!='':
			orf='5CDS-'+flag3
		elif flag5!='' and flag3=='':
			orf=flag5+'-3CDS'

		ORF=orf
		return ORF

print analORF(glist,bplist,dr1_info,dr2_info)


