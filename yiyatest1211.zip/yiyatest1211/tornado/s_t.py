
import pymysql
import json

import tornado.ioloop
import tornado.web
import os.path
import sys
from ensg import newarr
def import_data():
    # 读txt文件
# 连接数据库，获取游标
    #print()
    total=''
    total_num=0
    con = pymysql.connect("localhost", "root", "KEyiya19960302", "kyy", use_unicode=True, charset="utf8")
    cur = con.cursor()
    # for name in newpro:
        
    total=''
    with con:
        cur=con.cursor()
            # sql = "SELECT * FROM name_ensg \
            #    WHERE name = '%s'" % (name)
            # cur.execute(sql)
            # rows=cur.fetchall()
            
            # for row in rows:

            #     if row:
            #         total_num=total_num+1
            #         row=list(row)
            #         total=total+ '\''+row[1]+'\''+','
            #         if total_num % 8 == 0 :
            #              total=total+'\n'
                    
            #         print(row[1])
            #     else:
            #        # isempty=1
            #         print("empty")
        cur.execute("select chr,cdsstart,cdsend,name from gencode")

        data=cur.fetchall()
        for chrs,cdsstart,cdsend,name in data:
                #data=list(data)
            newstr=chrs+'   '+cdsstart+'   '+cdsend+'   '+name+'\r\n'
            total=total+newstr
            print (newstr)


    cur.close()

    filename = 'chrinfo.txt'
    with open(filename,'w') as f: # 如果filename不存在会自动创建， 'w'表示写数据，写之前会清空文件中的原有数据！
        f.write(total)
        

if __name__=='__main__':
    import_data()