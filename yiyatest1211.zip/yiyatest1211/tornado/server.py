# import tornado.ioloop
# import tornado.web
 
# class MainHandler(tornado.web.RequestHandler):
#     def get(self):
#         self.write("Hello, world")
 
# application = tornado.web.Application([
#     (r"/index", MainHandler),
# ])
 
# if __name__ == "__main__":
#     application.listen(8888)
#     tornado.ioloop.IOLoop.instance().start()

import tornado.ioloop
import tornado.web
import os.path
import sys
import pymysql
import json
import orf
import vcf_g_3
import time
import glob,re

sys.path.append("..")
CACHE_DIR=r'C:\Users\Administrator\Desktop\yiyatest1006\tornado\uploads'

front='aaa'
end='bbb'
temp_g=''
temp_bp=''
str_g_arr=[]
str_bp_arr=[]
bp_search=''
arr={'yiyake':18 }
dr1_info_=[]
dr2_info_=[]
class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("new_f.html")
    # def post(self):
        # front=self.get_argument("g1")
        # end=self.get_argument("g2")
class TablefgHandler(tornado.web.RequestHandler):
    def post(self):
        alldbinfo=[]
        allinfo={}
        dbinfo=self.get_argument("message")
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM db_fgs "
            cur.execute(sql)
            rows=cur.fetchall()
            print(len(rows))

            for row in rows:
                if row:
                    row=list(row)
                    alldbinfo.append(row)
                    #print(row)
                    
                else:
                    isempty=1
                    print("empty")
            allinfo['0']=alldbinfo
            #print(allindo)

        self.write(allinfo)    
          
                    
class DbHandler(tornado.web.RequestHandler):
    def post(self):
        alldbinfo=[]
        allinfo={}
        dbinfo=self.get_argument("message")
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM dbvar \
               WHERE ID = '%s'" % (dbinfo)
            cur.execute(sql)
            rows=cur.fetchall()
            print(len(rows))

            for row in rows:
                if row:
                    row=list(row)
                    alldbinfo.append(row)
                    #print(row)
                    
                else:
                    isempty=1
                    print("empty")
            allinfo['0']=alldbinfo
            print(len(allinfo))
            #print(allindo)

        self.write(allinfo)
def vcf_tog(gendir,vcfdir):
    inf=open(gendir,'r')
    inf1=open(vcfdir,'r')
    g_str_dic={}
    chr_loc_dic={}
    st_en_g_dic={}
    T=''
    chrlist=['1', '2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','X','Y']
    while 1:
        line=inf.readline()
        if not line: break

        gs=line[:-1].split('\t')
        chr=gs[2]
        if chr!='chrom' and len(chr.split('_'))==1:
            tsst=gs[4]
            tsen=gs[5]
            sten=tsst+'_'+tsen
            g=gs[12]

            st_en_g_dic[sten]=g
            g_str_dic[g]=gs[3]
            if chr in chr_loc_dic:
                temp=chr_loc_dic[chr]
                if sten not in temp:
                    temp.append(sten)
                    chr_loc_dic[chr]=temp
            else:
                temp=[]
                temp.append(sten)
                chr_loc_dic[chr]=temp


    while 1:
        line=inf1.readline()
        if not line: break
        gs=line.split('\t')
        if line[0]!='#':
            CHR1=gs[0]
            END1=gs[1]
            CHR2=''
            END2=''
            END=''
            SVLEN=0
            SVLEN_=0
            SVTYPE=''
            gss=gs[7].split(';')
            for gg in gss:
                ggs=gg.split('=')
                if ggs[0]=='CHR2':
                    if ggs[1]!=CHR1:
                        CHR2=ggs[1]
                if ggs[0]=='END':
                    END2=ggs[1]
                if ggs[0]=='SVTYPE':
                    SVTYPE=ggs[1]
                if ggs[0]=='SVLEN':
                    rang=re.findall(r'^[0-9]+\-[0-9]+$', ggs[1])
                    if len(rang)!=0:
                        rangs=rang[0].split('-')
                        st=int(rangs[0])
                        en=int(rangs[1])
                        SVLEN_=(st+en)/2

                    else:
                        if ggs[1]!='.':
                            SVLEN_=abs(int(ggs[1]))

            if SVTYPE in ['DEL','DUP','INV']:
                if CHR2=='' and SVLEN_>=100000 and CHR1 in chrlist:
                    SVLEN=SVLEN_
                    g1=''
                    chr1='chr'+CHR1
                    chr2=chr1
                    bp1=int(END1)
                    sten2s=chr_loc_dic[chr1]
                    bp2=int(END2)
                    tss1=0
                    tse1=0
                    tss2=0
                    tse2=0
                    g2=''
                    tss_gap1=0
                    tss_gap2=0
                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2] 
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 < tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten2s[i]]

                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print (T,'1')
                        return T

            elif SVTYPE in ['CTX', 'CPX', 'BND']:
                if CHR2=='' and SVLEN_>=100000 and CHR1 in chrlist:
                    SVLEN=SVLEN_
                    g1=''
                    chr1='chr'+CHR1
                    chr2=chr1
                    bp1=int(END1)
                    sten2s=chr_loc_dic[chr2]
                    bp2=int(END2)
                    tss1=0
                    tse1=0
                    tss2=0
                    tse2=0
                    g2=''
                    tss_gap1=0
                    tss_gap2=0
                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2] 
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 < tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten2s[i]]
                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print (T,'2')
                        return T
                if CHR2!='' and CHR1 in chrlist and CHR2 in chrlist:
                    g1=''
                    chr1='chr'+CHR1
                    chr2='chr'+CHR2
                    bp1=int(END1)
                    sten1s=chr_loc_dic[chr1]
                    sten2s=chr_loc_dic[chr2]
                    bp2=int(END2)
                    g2=''
                    for i in range(len(sten1s)):
                        sten2=sten1s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2]
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten1s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten1s[i]]

                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2]
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print (T,'3')
                        return T
class Upload(tornado.web.RequestHandler):
    """docstring for Upload"""
    def post(self):
        file = self.request.files
        ret = {}
        for key,value in file.items():
            for i in value:
                with open(os.path.join(CACHE_DIR,i['filename']),'wb') as f:
                    bodys = i['body']
                    f.write(bodys)
                print("写入{}文件完成！".format(i['filename']))
                FileList=[] 
                newdir=''
                mydir = "C:/Users/Administrator/Desktop/yiyatest1006/tornado/uploads"
                for root, dirs, files in os.walk(mydir):  
                    for file in files:  
                        if os.path.splitext(file)[1] == '.vcf':  

                            FileList=file
                            

                
                newlist=FileList
                print(newlist)
                dir_gen='gecode.txt'
                dir_vcf=newlist
                
                ifhasg=vcf_tog(dir_gen,dir_vcf)
                print(ifhasg)
                ret['gg']=ifhasg
                newdir=mydir+'/'+dir_vcf
                print(newdir)
                os.remove(newdir)
                # hello=vcf_g.hello(mydir)
                # t = Timer(10.0, hello) 
                # t.start()
                # time.sleep(5)
                # os.remove(dir_vcf)




        #ret = {'result': 'OK'}
        # upload_path = os.path.join(os.path.dirname(__file__), 'uploads')  # 文件的暂存路径
        # file_metas = self.request.files.get('file', None)  # 提取表单中‘name’为‘file’的文件元数据

        # if not file_metas:
        #     ret['result'] = 'Invalid Args'
        #     return ret

        # for meta in file_metas:
        #     filename = meta['filename']
        #     file_path = os.path.join(upload_path, filename)

        #     with open(file_path, 'wb') as up:
        #         up.write(meta['body'])
        #         # OR do other thing

        self.write(ret)

         

class Indexs(tornado.web.RequestHandler):      
    def get(self,ge1,ge2):
        print('Indexs_get', ge1, ge2)
        #self.render("index02.html",
        chrinfo1=ge1.split(':')[0]
        numinfo1=int(ge1.split(':')[1])
        chrinfo2=ge2.split(':')[0]
        numinfo2=int(ge2.split(':')[1])

        name1='0'
        name2='0'
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM chrinfo  where chrnum ='{}' and cdsstart < {}  and cdsend > {}".format(
                chrinfo1, numinfo1,numinfo1)
            print('going to use sqlL:', sql)
            cur.execute(sql)
            row=cur.fetchone()
            if row:

                print('dd')


                row=list(row)
                         # print(row)

                name1=row[2]
                print('find')
                print(name1+',name1')
            else:
                name1='0'


            sql = "SELECT * FROM chrinfo  where chrnum ='{}' and cdsstart < {}  and cdsend > {}".format(
                chrinfo2, numinfo2,numinfo2)
            print('going to use sqlL:', sql)


            cur.execute(sql)

            row=cur.fetchone()
            if row:

                row=list(row)
                         # print(row)

                name2=row[2]
                print('find')
                print(name2+'name2')

            else:
                name1='0'
        print('cc')
        print('name2:', name2)

        print( "108 {}:{}".format(name1, ge1))
        print("109 {}:{}".format(name2, ge2))

        self.render("index02.html",
        gen1=name1,
        gen2=name2,
        bpnum1=ge1,
        bpnum2=ge2,
            
        )
        tempstr=name1+'-'+name2   
        print(tempstr,'bp号码')
        print(str_bp_arr)
        for index,val in enumerate(str_g_arr):
            print(val)
            if tempstr==val:
                global bp_search
                bp_search=str_bp_arr[index]
                print(bp_search,'bp断点的下标')
        
        for index in range(len(str_bp_arr)):
            str_bp_arr[index]=''

        
    def post(self,ge1,ge2):
        front=self.get_argument("g1")
        end=self.get_argument("g2")
        bpinput1=self.get_argument("g1bp")
        bpinput2=self.get_argument("g2bp")
        print('来啦来啦来啦',bpinput1,'he',bpinput2)
        import time
        mytime = int(time.time())

        myurl='/test'

        if mytime:
            self.redirect('/test'+'/'+bpinput1+'/'+bpinput2)  

class HylinkinfoHandler(tornado.web.RequestHandler):
    def post(self):
        box_text=self.get_argument("message")
        text_arr=box_text.split("+")
        global str_bp_arr
        global str_g_arr
        str_g_arr=text_arr[0].splitlines()
        str_bp_arr=text_arr[1].splitlines()
        print('苦瓜那个苦瓜那个',str_g_arr,str_bp_arr)
class SingleHandler(tornado.web.RequestHandler):
    def post(self):
        print('diliver')
        infoend=self.get_argument("message")
        namesend=infoend.split("+")[0]
        chrend=infoend.split("+")[1]

        
        #name_arr=namesend.split(",")
        print('chuanlaideinfo',namesend)
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        allchrinfo=''
        allchrtenp={}

        with con:
            cur=con.cursor()
            bpnum=0
            chrnewinfo=''
            if chrend:
                chrendnum=chrend.split(":")[1]
                chrendchr=chrend.split(":")[0]
                sql = "SELECT * FROM chrinfo  where chrnum ='{}' and cdsstart < {}  and cdsend > {}".format(
                chrendchr, chrendnum,chrendnum)
                    #print('going to use sqlL:', sql)
                cur.execute(sql)
                row=cur.fetchone()
                    
                    
                if row:
                    print('hh')


                    
                    chrnewinfo=chrend
                    print('find')
                    print(chrnewinfo+',name1')
                else:
                    print('0')

                
            else:
                sql = "SELECT * FROM chrinfo where name ='{}'".format(namesend)
                    #print('going to use sqlL:', sql)
                cur.execute(sql)
                row=cur.fetchone()
                    
                    
                if row:
                    print('hh')


                    row=list(row)
                                 # print(row)

                    mychrnum=int(row[0])+5
                    mychrstr=row[3]
                    chrnewinfo=mychrstr+':'+str(mychrnum)
                    print('find')
                    print(chrnewinfo+',name1')
                else:
                    print('0')
                
                
            
            allchrinfo=chrnewinfo
            
        allchrtenp[0]=allchrinfo
        # k=0
        # for i in range(len(allchrinfo)):
        #     allchrtenp[k]=allchrinfo[i]
        #     k=k+1
        self.write(allchrtenp)
class NameHandler(tornado.web.RequestHandler):
    def post(self):
        chrsend=self.get_argument("message")
        chr_arr=chrsend.split(",")
        print(chr_arr)
        
        allchrinfo=''
        allchrtenp={}
        namenum=0
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            for chrs in chr_arr:
                namenum=namenum+1
                chrinfo1=chrs.split(':')[0]
                numinfo1=int(chrs.split(':')[1])


                name1='0'

            
                cur=con.cursor()
                sql = "SELECT * FROM chrinfo  where chrnum ='{}' and cdsstart < {}  and cdsend > {}".format(
                    chrinfo1, numinfo1,numinfo1)
                print('going to use sqlL:', sql)
                cur.execute(sql)
                row=cur.fetchone()
                if row:

                    print('dd')


                    row=list(row)
                             # print(row)

                    name1=row[2]

                    print('find')
                    print(name1+',name1')

                else:
                    name1='0'
                if namenum%2==1:
                    allchrinfo=allchrinfo+name1+'-'
                else:
                    allchrinfo=allchrinfo+name1+'\n'


        allchrtenp[0]=allchrinfo
        print('生成的那么',allchrinfo)
        # k=0
        # for i in range(len(allchrinfo)):
        #     allchrtenp[k]=allchrinfo[i]
        #     k=k+1
        self.write(allchrtenp)
class ChrHandler(tornado.web.RequestHandler):
    def post(self):
        namesend=self.get_argument("message")
        name_arr=namesend.split(",")
        print(name_arr)
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        allchrinfo=''
        allchrtenp={}

        with con:
            cur=con.cursor()
            bpnum=0
            chrnewinfo=''
            for name in name_arr:
                bpnum=bpnum+1
                sql = "SELECT * FROM chrinfo where name ='{}'".format(name)
                #print('going to use sqlL:', sql)
                cur.execute(sql)
                row=cur.fetchone()
                
                
                if row:
                    print('hh')


                    row=list(row)
                             # print(row)

                    mychrnum=int(row[0])+5
                    mychrstr=row[3]
                    chrnewinfo=mychrstr+':'+str(mychrnum)
                    print('find')
                    print(chrnewinfo+',name1')
                else:
                    print('0')
                
                if bpnum%2==1:
                    allchrinfo=allchrinfo+chrnewinfo+'-'
                else:
                    allchrinfo=allchrinfo+chrnewinfo+'\n'
        allchrtenp[0]=allchrinfo
        # k=0
        # for i in range(len(allchrinfo)):
        #     allchrtenp[k]=allchrinfo[i]
        #     k=k+1
        self.write(allchrtenp)

class IsprinfoHandler(tornado.web.RequestHandler):
    def post(self):
        need_text=self.get_argument("message")   
        info_arr=need_text.split("+")
        glist=['0','1']
        bplist=['0','1']
        glist[0]=info_arr[0]
        glist[1]=info_arr[1]
        bplist[0]=info_arr[2]
        bplist[1]=info_arr[3]
        print('dri_info',dr1_info_)
        print('dr2_info',dr2_info_)
        print(info_arr,glist,bplist,dr1_info_,dr2_info_)
        myres=analORF(glist,bplist,dr1_info_,dr2_info_)
        print(myres)
        self.write(myres)


class KdinfoHandler(tornado.web.RequestHandler):
    def post(self):
        mykdinfo={}
        kdallinfo=[]
        name_1=''
        name_2=''
        count_bp1=0;
        count_bp2=0;
        bp1=''
        bp2=''
        dis1=''
        dis2=''
        bp1str=''
        bp2str=''
        bp1arr=[]
        bp2arr=[]
        c=self.get_argument("message")
        codes=c.split('+')

        name_1=codes[0]
        name_2=codes[1]
        #print("Debug:")
        print("kdinfo print:")
        print(self.get_argument("message"))
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM knownbp \
               WHERE gene = '%s'" % (name_1)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:

                if row:
                    count_bp1=count_bp1+1;
                    row=list(row)
                    # kdallinfo.append(row[2])
                    bp1=bp1+row[2]
                    bp1=bp1+','+'  '
                    bp1arr.append(int(row[2]))
                    # print(row[2])
                else:
                   # isempty=1
                    print("empty")
            bp1arr.sort()

            for bpnum in bp1arr:
                bp1str=bp1str+str(bpnum)+','+'  '
            #print(bp1str)
            kdallinfo.append(bp1str)
              
            sql = "SELECT * FROM knownbp \
               WHERE gene = '%s'" % (name_2)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:

                if row:
                    count_bp2=count_bp2+1;
                    row=list(row)
                    # kdallinfo.append(row[2])
                    bp2=bp2+row[2]
                    bp2=bp2+','+'  '
                    bp2arr.append(int(row[2]))
                    # print(row[2])
                else:
                   # isempty=1
                    print("empty")  
            bp2arr.sort()
            for bpnum in bp2arr:
                bp2str=bp2str+str(bpnum)+','+'  '
            kdallinfo.append(bp2str)

             
            sql = "SELECT * FROM disease \
               WHERE gene = '%s'" % (name_1)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:

                if row:
                    # count_bp2=count_bp2+1;
                    row=list(row)
                    # kdallinfo.append(row[2])
                    dis1=dis1+row[1]
                    dis1=dis1+','
                    # print(row[2])
                else:
                   # isempty=1
                    print("empty")  
            kdallinfo.append(dis1)
            
            sql = "SELECT * FROM disease \
               WHERE gene = '%s'" % (name_2)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:

                if row:
                    # count_bp2=count_bp2+1;
                    row=list(row)
                    # kdallinfo.append(row[2])
                    dis2=dis2+row[1]
                    dis2=dis2+','
                    # print(row[2])
                else:
                   # isempty=1
                    print("empty")  
            global bp_search
            kdallinfo.append(dis2)
            kdallinfo.append(count_bp1)
            kdallinfo.append(count_bp2)
            kdallinfo.append(bp_search)
            print(bp_search)
            bp_search=''
            k=0
            for i in range(len(kdallinfo)):
                mykdinfo[k]=kdallinfo[i]
                k=k+1
        con.close()
        self.write(mykdinfo)


class FeatureHandler(tornado.web.RequestHandler):
    def post(self):
        code_1=''
        code_2=''
        name_1=''
        name_2=''
        dr1_info=[]
        dr2_info=[]
        dr_all=[]
        codeempty=0
        dr_info={}
        count_1=0
        count_2=0
        c=self.get_argument("message")
        #print("Debug:")
        print(self.get_argument("message"))
        #back='aaaa'
        codes=c.split('+')

        name_1=codes[0]
        name_2=codes[1]
        enstg_1=[]
        enstg_2=[]
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM g_enst \
               WHERE g_name = '%s'" % (name_1)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:
                if row:
                    row=list(row)
                   # print(row)
                   # g1_id=row[1]
                    for i in row:
                        enstg_1.append(i)
                else:
                   # isempty=1
                    print("empty")
            code_1=enstg_1[2]

            sql = "SELECT * FROM g_enst \
               WHERE g_name = '%s'" % (name_2)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:
                if row:
                    row=list(row)
                   # print(row)
                   # g1_id=row[1]
                    for i in row:
                        enstg_2.append(i)
                else:
                   # isempty=1
                    print("empty")
            code_2=enstg_2[2]



            sql = "SELECT * FROM gencode \
               WHERE enst = '%s'" % (code_1)
            cur.execute(sql)
            rows=cur.fetchall()
            global  dr1_info_
            for row in rows:
                if row:
                    row=list(row)
                    dr1_info_=row
                    # print(row)
                    for i in row:
                        dr1_info.append(i)
                        dr_all.append(i)
                else:
                    codeempty=1
                    print("empty")
            # print(dr1_info)

            #print(len(g1info))
            if len(dr1_info)==0:
                codeempty=1
                print("empty")
            
            sql = "SELECT * FROM gencode \
               WHERE enst = '%s'" % (code_2)
            cur.execute(sql)
            rows=cur.fetchall()
            global dr2_info_
            for row in rows:
                if row:
                    row=list(row)
                    dr2_info_=row
                    # print(row)
                    for i in row:
                        dr2_info.append(i)
                        dr_all.append(i)
                else:
                    codeempty=1
                    print("empty")
            # print(dr2_info)
            sql = "SELECT * FROM mir \
               WHERE gene = '%s'" % (name_1)
            cur.execute(sql)
            row=cur.fetchone()
            if row:
                row=list(row)
                 # print(row)
                for i in row:
                    dr_all.append(i)
            else:
                dr_all.append('0')
                dr_all.append('0')
                dr_all.append('0')


            sql = "SELECT * FROM mir \
               WHERE gene = '%s'" % (name_2)
            cur.execute(sql)
            row=cur.fetchone()
            if row:
                row=list(row)
                # print(row)
                for i in row:
                    dr_all.append(i)

            else:
                dr_all.append('0')
                dr_all.append('0')
                dr_all.append('0')



            sql = "SELECT * FROM tf \
               WHERE gene = '%s'" % (name_1)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
            else:
                dr_all.append('0')
                dr_all.append('0')

            sql = "SELECT * FROM tf \
               WHERE gene = '%s'" % (name_2)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
            else:
                dr_all.append('0')
                dr_all.append('0')

            sql = "SELECT * FROM mrnaseq \
               WHERE enst = '%s'" % (code_1)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
            else:
                dr_all.append('0')
                dr_all.append('0')
                dr_all.append('0')

            sql = "SELECT * FROM mrnaseq \
               WHERE enst = '%s'" % (code_2)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
            else:
                dr_all.append('0')
                dr_all.append('0')
                dr_all.append('0')

            sql = "SELECT * FROM variant \
               WHERE name = '%s'" % (name_1)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
                    count_1=count_1+1
            else:
                count_1=0


            sql = "SELECT * FROM variant \
               WHERE name = '%s'" % (name_2)
            cur.execute(sql)
            rows=cur.fetchall()
            if rows:
                for row in rows:
                    if row:
                        row=list(row)
                        # print(row)
                        for i in row:
                            dr_all.append(i)
                    count_2=count_2+1
            else:
                count_2=0

            dr_all.append(count_1)
            dr_all.append(count_2)
            #print(len(g1info))
            if len(dr2_info)==0:
                codeempty=1
                # print("empty")
            k=0
            if codeempty==0:
                #print(dr_all)
                for i in range(len(dr_all)):
                    dr_info[k]=dr_all[i]
                    k=k+1
                
        con.close()
        if codeempty==0:
            self.write(dr_info)
        else:
            print("empty")
            self.write('no') 
        # self.write('yes')

class AjaxHandler(tornado.web.RequestHandler):
    def post(self):
        g1_id=''
        g2_id=''
        g1info=[]
        g2info=[]
        f1_infos=[]
        f2_infos=[]
        all_data=[]
        all_info={}
        isempty=0
        #self.write("hello world")
        gstr=self.get_argument("message")
        print(self.get_argument("message"))
        g_name=gstr.split('+')
        g1=g_name[0]
        g2=g_name[1]
        print(g1,'linkdatag1')
        print(g2,'linkdatag2')
        g1_n=g1
        g2_n=g2
        con=pymysql.connect('127.0.0.1','root','KEyiya19960302','kyy')
        with con:
            cur=con.cursor()
            sql = "SELECT * FROM g_enst \
               WHERE g_name = '%s'" % (g1_n)
            cur.execute(sql)
            rows=cur.fetchall()

            for row in rows:
                if row:
                    row=list(row)
                    print(row)
                    g1_id=row[1]
                    for i in row:
                        g1info.append(i)
                else:
                    isempty=1
                    print("empty")
            #print(g1info)

            print(len(g1info))
            if len(g1info)==0:
                isempty=1
                print("empty")


            sql = "SELECT * FROM g_enst \
               WHERE g_name = '%s'" % (g2_n)
            cur.execute(sql)
            rows=cur.fetchall()
            for row in rows:
                if row:
                    row=list(row)
                    print(row)
                    g2_id=row[1]
                    for i in row:
                       g2info.append(i)
                else:
                    isempty=1
                    print("empty")
            #print(g2info)
            print(len(g2info))
            if len(g2info)==0:
                isempty=1
                print("empty")

            sql2= "SELECT * FROM g_seqs \
               WHERE g_id = '%s'" % (g1_id)
            cur.execute(sql2)
            results=cur.fetchall()
            for line in results:
                if line:
                    line=list(line)
                    g1info.append(line[1])
                    g1info.append(line[2])
                else:
                    isempty=1
                    print("empty")
            print(len(g1info))
            if len(g1info)==0:
                isempty=1
                print("empty")


            g1info.append(0)  
            #print(g1info)
            all_data.append(g1info)

            sql2= "SELECT * FROM g_seqs \
               WHERE g_id = '%s'" % (g2_id)
            cur.execute(sql2)
            results=cur.fetchall()
            for line in results:
                if line:
                    line=list(line)
                    g2info.append(line[1])
                    g2info.append(line[2])
                else:
                    isempty=1
                    print("empty")
            print(len(g2info))
            if len(g2info)==0:
                isempty=1
                print("empty")


            g2info.append(0)    
            #print(g2info)
            all_data.append(g2info)

            sql3= "SELECT * FROM f_info \
               WHERE f_id = '%s'" % (g1_id)
            cur.execute(sql3)
            f1_result=cur.fetchall()
            for line in f1_result:
                if line:
                    line=list(line)
                    f1_infos.append(line)
                    all_data.append(line)
                else:
                    isempty=1
                    print("empty")
            print(len(f1_infos))
            if len(f1_infos)==0:
                isempty=1
                print("empty")
            #all_data.append(f1_infos)

            sql3= "SELECT * FROM f_info \
               WHERE f_id = '%s'" % (g2_id)
            cur.execute(sql3)
            f2_result=cur.fetchall()
            for line in f2_result:
                if line:
                    line=list(line)
                    f2_infos.append(line)
                    all_data.append(line)
                else:
                    isempty=1
                    print("empty")
                
            print(len(f2_infos))
            if len(f2_infos)==0:
                isempty=1
                print("empty")
#all_data.append(f2_infos)
            print(len(all_data))
            k=0
            if isempty==0:
                for i in range(len(all_data)):
                    for j in range(len(all_data[0])):
                        all_info[k]=all_data[i][j]
                        k=k+1

            #print(all_info)
        print(isempty)
        print('8888888888888888888888888')          
        con.close()
        if isempty==0:
            self.write(all_info)
        else:
            print("empty")
            self.write('no')

def analORF(glist,bplist,dr1_info,dr2_info):
    ORF=''
    if glist!=[] and bplist!=[] and dr1_info!=[] and dr2_info!=[]:
        g=glist[0]
        tg=glist[1]
        BP=bplist[0]
        tBP=bplist[1]
        bp=int(BP.split(':')[1])
        bp2=int(tBP.split(':')[1])
        ebp=0
        ebp2=0
        nm=dr1_info[1].split('.')[0]
        strand=dr1_info[3]
        exs_=dr1_info[9].split(',')[:-1]
        exe_=dr1_info[10].split(',')[:-1]
        exs=[int(i) for i in exs_]
        exe=[int(i) for i in exe_]
        cds=int(dr1_info[6])
        cde=int(dr1_info[7])
        chr1=dr1_info[2]
        nm2=dr2_info[1].split('.')[0]
        strand2=dr2_info[3]
        exs2_=dr2_info[9].split(',')[:-1]
        exe2_=dr2_info[10].split(',')[:-1]
        exs2=[int(i) for i in exs2_]
        exe2=[int(i) for i in exe2_]
        cds2=int(dr2_info[6])
        cde2=int(dr2_info[7])
        chr2=dr2_info[2]
        mrnalen=0
        realbpmrna=0
        left=0
        flag5=''
        flag3=''
        lenex=len(exs)
        if strand=='+':
            #print '+ strand1'
            cdssexi=10000
            cdseexi=10000
            mrnastr=[]
            bpexon=10000 # BP at the exon junction
            bpexon_=10000 # BP in the middle of exon
            bpexon__=10000 # BP in the middle of intron
            mrnastr2=[]
            for e in range(len(exs)):
                mrnalen+=exe[e]-exs[e]
                mrnastr.append(exe[e]-exs[e])
                mrnastr2.append(mrnalen)
                if exs[e]<=cds<=exe[e]:
                    cdssexi=e
                if exs[e]<=cde<=exe[e]:
                    cdseexi=e

                if exe[e]<= bp and bp <=exe[e]+6:
                    bpexon=e
                    ebp=exe[e]
                if exs[e]< bp and bp <exe[e]:
                    bpexon_=e
                    ebp=bp
                if e!=0 and e!=len(exs)-1:
                    if exe[e-1]+6< bp and bp<exs[e]-6:
                        bpexon__=e-1
                        #bpexon=e-1

            #print chr1
            #print bp
            #print exs
            #print exe
            #print 'bpexon='+str(bpexon)
            #print 'bpexon_='+str(bpexon_)
            #print 'bpexon__='+str(bpexon__)
            #print 'cdssexi='+str(cdssexi)
                        #print 'cdseexi='+str(cdseexi)

            if (cdssexi!=10000 and bpexon!=10000) or (cdssexi!=10000 and bpexon_!=10000):
                #print '>1'
                cd5=0
                if ebp < cds and exs[0]<ebp:
                    flag5='5UTR'
                elif cde < ebp and ebp<exe[lenex-1]:
                    flag5='3UTR'
                else:
                    if bpexon!=10000:
                        #print '>1_1'
                        if bpexon==cdssexi:
                            cd5=abs(exe[bpexon]-cds)
                        elif cdssexi<bpexon:
                            for a in range(bpexon-cdssexi+1):
                                if a==0:
                                    cd5+=exe[cdssexi+a]-cds
                                else:
                                    cd5+=exe[cdssexi+a]-exs[cdssexi+a]
                    if bpexon_!=10000:
                        #print '>1_2'
                        if bpexon_==cdssexi:
                            cd5=abs(bp-cds)
                        elif cdssexi<bpexon_:
                            for a in range(bpexon_-cdssexi+1):
                                if a==0:
                                    cd5+=exe[cdssexi+a]-cds
                                elif a==(bpexon_-cdssexi):
                                    cd5+=bp-exs[cdssexi+a]
                                else:
                                    cd5+=exe[cdssexi+a]-exs[cdssexi+a]
                    realbpmrna=cd5/3
                    left=cd5%3
            else:
                flag5='intron'  

        else:
            #print '- strnad1'
            cdssexi=10000
            cdseexi=10000
            mrnastr=[]
            mrnastr2=[]
            bpexon=10000
            bpexon_=10000
            for e in range(len(exs)):
                mrnalen+=exe[lenex-e-1]-exs[lenex-e-1]
                mrnastr.append(exe[lenex-e-1]-exs[lenex-e-1])
                mrnastr2.append(mrnalen)
                if exs[lenex-e-1]<=cds<=exe[lenex-e-1]:
                    cdseexi=lenex-e-1
                if exs[lenex-e-1]<=cde<=exe[lenex-e-1]:
                    cdssexi=lenex-e-1

                if exs[lenex-e-1]-6<= bp and bp <=exs[lenex-e-1]:
                    bpexon=e
                    ebp=exs[lenex-e-1]
                if exs[lenex-e-1]< bp and bp <exe[lenex-e-1]:
                    bpexon_=e
                    ebp=bp
                    if e!=0 and e!=len(exs)-1:
                        if exe[lenex-e-2]+6<bp and bp <exs[lenex-e-1]-6:
                            bpexon__=e
                        #bpexon=e

            if (cdseexi!=10000 and bpexon!=10000) or (cdseexi!=10000 and bpexon_!=10000):
                #print '>2'
                cd5=0
                if cde < ebp and ebp<exe[lenex-1]:
                    flag5='5UTR'
                elif ebp < cds and exs[0]<ebp:
                    flag5='3UTR'
                else:
                    if bpexon!=10000:
                        #print '>2_1'
                        if bpexon==lenex-cdseexi:
                            cd5=abs(exs[lenex-bpexon-1]-cde)
                        elif cdseexi<bpexon:
                            for a in range(bpexon-cdseexi+1):
                                if a==0:
                                    cd5+=cde-exs[lenex-1]
                                else:
                                    cd5+=exe[lenex-a-1]-exs[lenex-a-1]
                    if bpexon_!=10000:
                        #print '>2_2'
                        if bpexon_==lenex-cdseexi:
                            cd5=abs(bp-cde)
                        elif cdseexi<bpexon_:
                            for a in range(bpexon_-cdseexi+1):
                                if a==0:
                                    cd5+=cde-exs[lenex-1]
                                elif a==bpexon_-cdssexi:
                                    cd5+=exe[lene-a-1]-bp
                                else:
                                    cd5+=exe[lenex-a-1]-exs[lenex-a-1]

                    realbpmrna=cd5/3
                    left=cd5%3
            else:
                flag5='intron'
        
        lenex2=len(exs2)
        mrnalen2=0
        realbpmrna2=0
        right=0

        #print chr2
        #print bp2
        #print exs2
        #print exe2
        if strand2=='+':
            #print '+ strand2'
            cdssexi2=10000
            cdseexi2=10000
            mrnastr2_=[]
            bpexon2=10000
            bpexon22=10000
            bpexon222=10000
            mrnastr22_=[]
            for e2 in range(len(exs2)):

                mrnalen2+=exe2[e2]-exs2[e2]
                mrnastr2_.append(exe2[e2]-exs2[e2])
                mrnastr22_.append(mrnalen2)
                if exs2[e2]<=cds2<=exe2[e2]:
                    cdssexi2=e2
                if exs2[e2]<=cde2<=exe2[e2]:
                    cdseexi2=e2

                if exs2[e2]-6<=bp2 and bp2 <=exs2[e2]:
                    bpexon2=e2
                    ebp2=exs2[e2]
                    #print '1--bpexon2='+str(bpexon2)
                if exs2[e2]<bp2 and bp2 <exe2[e2]:
                    bpexon22=e2
                    ebp2=bp2
                    #print '2--bpexon2='+str(bpexon2)
                    if e2!=0 and e2!=len(exs2)-1:
                    #print '2222'
                        if exe2[e2]+6<bp2 and bp2 <exs2[e2+1]-6:
                        #print '3--bpexon2='+str(bpexon2)
                            bpexon222=e2+1
                                                #bpexon2=e2+1
                        #print '3--bpexon2='+str(bpexon2)
                        #print '3--bpexon222='+str(bpexon222)

                        #print 'bpexon2='+str(bpexon2)
                        #print 'bpexon22='+str(bpexon22)
                        #print 'bpexon222='+str(bpexon222)
                        #print 'cdssexi2='+str(cdssexi2)
                        #print 'cdseexi2='+str(cdseexi2)

            if (cdseexi2!=10000 and bpexon2!=10000) or (cdseexi2!=10000 and bpexon22!=10000):
                #print '>_1'

                if cde2<ebp2 and ebp2<exe2[lenex2-1]:
                    flag3='3UTR'
                    
                elif ebp2<cds2 and exs2[0]<ebp2:
                    flag3='5UTR'
                else:
                    cd3=0
                    if bpexon2!=10000:
                        #print '>_1_1'
                        if bpexon2==cdseexi2:
                            cd3=abs(exe2[bpexon2]-cde2)
                        elif bpexon2<cdseexi2:
                            for a in range(cdseexi2-bpexon2+1):
                                if a==cdseexi2-bpexon2:
                                    cd3+=cde2-exs2[bpexon2+a]
                                else:
                                    cd3+=exe2[bpexon2+a]-exs2[bpexon2+a]
                    if bpexon22!=10000:
                        #print '>_1_2'
                        if bpexon22==cdseexi2:
                            cd3=abs(bp2-cde2)
                        elif bpexon22<cdseexi2:
                            for a in range(cdseexi2-bpexon22+1):
                                if a==cdseexi2-bpexon22:
                                    cd3+=cde2-exs2[bpexon22+a]
                                elif a==0:
                                    cd3+=exe2[bpexon22+a]-bp2
                                else:
                                    cd3+=exe2[bpexon22+a]-exs2[bpexon22+a]


                    realbpmrna=cd3/3
                    right=cd3%3
            else:
                flag3='intron'

        else:
            #print '- strand2'
            cdssexi2=10000
            cdseexi2=10000
            mrnastr2_=[]
            mrnastr22_=[]
            bpexon2=10000
            bpexon22=10000
            bpexon222=10000
            for e2 in range(len(exs2)):
                mrnalen2+=exe2[lenex2-e2-1]-exs2[lenex2-e2-1]
                mrnastr2_.append(exe2[lenex2-e2-1]-exs2[lenex2-e2-1])
                mrnastr22_.append(mrnalen2)
                if exs2[lenex2-e2-1]<=cds2<=exe2[lenex2-e2-1]:
                    cdseexi2=lenex2-e2-1
                if exs2[lenex2-e2-1]<=cde2<=exe2[lenex2-e2-1]:
                    cdssexi2=lenex2-e2-1

                if exe2[lenex2-e2-1]<= bp2 and bp2 <=exe2[lenex2-e2-1]+6:
                    bpexon2=e2
                    ebp2=exe2[lenex2-e2-1]

                if exs2[lenex2-e2-1]< bp2 and bp2 <exe2[lenex2-e2-1]:
                    bpexon22=e2
                    ebp2=bp2
                    if e2!=0 and e2!=len(exs2)-1:
                        if exe2[lenex2-e2-2]+6<bp2 and bp2 <exs2[lenex2-e2-1]-6:
                            bpexon222=e2-1
                                                #bpexon2=e2-1

                        #print 'bpexon2='+str(bpexon2)
                        #print 'bpexon22='+str(bpexon22)
                        #print 'bpexon222='+str(bpexon222)
                        #print 'cdssexi2='+str(cdssexi2)
                        #print 'cdseexi2='+str(cdseexi2)
            #print 'lenex2='+str(lenex2)

            if (cdseexi2!=10000 and bpexon2!=10000) or (cdseexi2!=10000 and bpexon22!=10000):
                #print '>_2'
                if cde2 < ebp2 and ebp2<exe2[lenex2-1]:
                    flag3='5UTR'
                elif ebp2 < cds2 and exs2[0]<ebp2:  
                    flag3='3UTR'
                else:
                    cd3=0
                    if bpexon2!=10000:
                        #print '>_2_1'
                        if bpexon2==lenex2-cdseexi2-1:
                            #print '--1'
                            cd3=abs(exe2[bpexon2]-cds2)
                        elif cdseexi2<bpexon2:

                            for a in range((lenex2-bpexon2)-cdseexi2):
                                if a==0:
                                    cd3+=exe2[cdseexi2+a]-cds2
                                    #print '--2'
                                else:
                                    cd3+=exe2[cdseexi2+a]-exs2[cdseexi2+a]
                                    #print '--3'
                    if bpexon22!=10000:
                        #print '>_2_2'
                        if bpexon22==lenex2-cdseexi2-1:
                            cd3=exe2[bpexon22]-cds2
                        elif cdseexi2<bpexon22:
                            for a in range((lenex2-bpexon22)-cdseexi2):
                                if a==0:
                                    cd3+=exe2[cdseexi2+a]-cds2
                                elif a==(lenex2-bpexon22)-cdseexi2-1:
                                    cd3+=bp2-exs2[cdseexi2+a]
                                else:
                                    cd3+=exe2[cdseexi2+a]-exs2[cdseexi2+a]

                    realbpmrna=cd3/3
                    right=cd3%3
            else:
                flag3='intron'

        #print flag5
        #print flag3
        #print left
        #print right

        orf=''
        if flag5=='' and flag3=='':
            summ=left+right
            if summ%3==0:
                orf='In-frame'
            else:
                orf='Frame-shift'
        elif flag5!='' and flag3!='':
            orf=flag5+'-'+flag3
        elif flag5=='' and flag3!='':
            orf='5CDS-'+flag3
        elif flag5!='' and flag3=='':
            orf=flag5+'-3CDS'

        ORF=orf
        return ORF



application = tornado.web.Application([
    (r"/", MainHandler),
    # (r"/test/^(?![a-zA-Z0-9]+$)(?![^a-zA-Z/D]+$)(?![^0-9/D]+$).{10,20}$", Indexs),
    # (r"/test/([0-9a-zA-Z\_]+)/([0-9a-zA-Z\_]+)", Indexs),
    (r"/singlechr", SingleHandler),
    (r"/searchchr", ChrHandler),
    (r"/chrsearchname", NameHandler),
    (r"/test/(.*)/(.*)", Indexs),
    (r"/test", AjaxHandler),
    (r"/myfeature", FeatureHandler),
    (r"/kdinfo", KdinfoHandler),
    (r"/hylinkinfo", HylinkinfoHandler),
    (r"/isprinfo", IsprinfoHandler),
    (r"/upload", Upload),
    (r"/dbforfg",DbHandler),
    (r"/dbfg",TablefgHandler),
    ],
    static_path = os.path.join(os.path.dirname(__file__), "static"),
    )

if __name__ == '__main__':
    settings = {
        "static_path": os.path.join(os.path.dirname(__file__), "static"),
    }
    application.listen(8000)
    tornado.ioloop.IOLoop.instance().start()