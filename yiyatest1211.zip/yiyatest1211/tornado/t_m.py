import pymysql
import json
def import_data(fn):
    # 读txt文件
    f = open(fn, 'r')
    m = f.readlines()

    print(m)
# 连接数据库，获取游标
    con = pymysql.connect("localhost", "root", "KEyiya19960302", "kyy", use_unicode=True, charset="utf8")
    cur = con.cursor()

# 执行sql语句
    for line in m:
        if line!='\n':
            A = line.strip('\n').split()
       # print(A)  # 这是未去掉空格的列表

        
            A2 = []
            for a in A:
                b = a.strip(' ')
                A2.append(b)
            print(A2)  # 这是去掉空格之后的列表

    # s = {'kbids': A2[1:]}  # 转成字典
    # # print(s)

    # a_json = json.dumps(s)
    # 
        #print(A2)  # 转成json字符串
            #intensg=A2[6].split('.')[0]
            value = (A2[1],A2[2],A2[3],A2[0])
            print(value)
        # #print(work)

        # #sql = "INSERT INTO familyk(name,who,work)VALUES (%s,%s,%s)"
            cur.execute("INSERT INTO chrinfo(cdsstart,cdsend,name,chrnum)VALUES (%s,%s,%s,%s)",value)
    # sql = "insert into yyt(rank,value,aa)values(\"%s\",'%s',now())"
    # sql1 = sql % (A2[0], a_json)
    # # print(sql1)

    # cur.execute(sql1)
            con.commit()

    cur.close()

if __name__=='__main__':
    import_data('chrinfo.txt')


