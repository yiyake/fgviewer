#inf=open('refGene.txt','r')
import glob
import os
dirgen='gencode19.txt'
dirvcf='nstd33.GRCh38.variant_call.vcf'
def vcf_tog(dirgen,dirvcf):
    inf=open(dirgen,'r')

    flist=glob.glob(dirvcf)
    g_str_dic={}
    chr_loc_dic={}
    st_en_g_dic={}
    while 1:
        line=inf.readline()
        if not line: break

        gs=line[:-1].split('\t')
        chr=gs[2]
        if chr!='chrom' and len(chr.split('_'))==1:
            tsst=gs[4]
            tsen=gs[5]
            sten=tsst+'_'+tsen
            g=gs[12]

            st_en_g_dic[sten]=g
            g_str_dic[g]=gs[3]
            #if key1 in adict: 
            if chr in chr_loc_dic:
                temp=chr_loc_dic[chr]
                if sten not in temp:
                    temp.append(sten)
                    chr_loc_dic[chr]=temp
            else:
                temp=[]
                temp.append(sten)
                chr_loc_dic[chr]=temp

    for f in flist:
        print (f)
        inf=open(f,'r')
        did=f.split('.')[0]
        while 1:
            line=inf.readline()
            if not line: break
            gs=line.split('\t')
            if line[0]!='#' and len(gs[0].split('_'))==1:
                g1=''
                chr1='chr'+gs[0]
                bp1=int(gs[1])
                sten1s=chr_loc_dic[chr1]
                for i in range(len(sten1s)):
                    sten1=sten1s[i].split('_')
                    sten1ss = [int(ii) for ii in sten1]
                    if sten1ss[0]-6<bp1 and bp1<sten1ss[1]+6:
                        if sten1s[i] in st_en_g_dic:
                            g1=st_en_g_dic[sten1s[i]]
                            g2=''
                            chr2=''
                            bp2=0
                dd=gs[4].split('[')
                dd2=gs[4].split(']')


                if len(dd)>1:
                    locs=dd[1].split(':')
                    chr2='chr'+locs[0]
                    bp2=int(locs[1])
                    sten2s=chr_loc_dic[chr2]
                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2] 
                        if sten2ss[0]-6<bp2 and bp2<sten2ss[1]+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]

                            if len(dd2)>1:
                                locs2=dd2[1].split(':')
                                chr2='chr'+locs2[0]
                                bp2=int(locs2[1])
                                sten2s=chr_loc_dic[chr2]
                                for i in range(len(sten2s)):
                                    sten2=sten2s[i].split('_')
                                    sten2ss = [int(ii) for ii in sten2]
                                    if sten2ss[0]-6<bp2 and bp2<sten2ss[1]+6:
                                        if sten2s[i] in st_en_g_dic:
                                            g2=st_en_g_dic[sten2s[i]]

                if g1!='' and g2!='':
                    T=did+'\t'+chr1+'\t'+str(bp1)+'\t'+g1+'\t'+chr2+'\t'+str(bp2)+'\t'+g2+'\n'
                    #print(T)
                    if T == None :
                        return 0
                    else:
                        return T
                    #outf.write(T)
                    #outf.flush()



   


newg=vcf_tog(dirgen,dirvcf)
print('g',newg)