import glob,re
gendir='gecode.txt'
vcfdir='nstd33.GRCh38.variant_call.vcf'
#inf=open('gencode.v28.txt','r')
#inf1=open('nstd33.GRCh38.variant_call.vcf','r')
def vcf_tog(gendir,vcfdir):
    inf=open(gendir,'r')
    inf1=open(vcfdir,'r')
    g_str_dic={}
    chr_loc_dic={}
    st_en_g_dic={}
    chrlist=['1', '2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','X','Y']
    while 1:
        line=inf.readline()
        if not line: break

        gs=line[:-1].split('\t')
        chr=gs[2]
        if chr!='chrom' and len(chr.split('_'))==1:
            tsst=gs[4]
            tsen=gs[5]
            sten=tsst+'_'+tsen
            g=gs[12]

            st_en_g_dic[sten]=g
            g_str_dic[g]=gs[3]
            if chr in chr_loc_dic:
                temp=chr_loc_dic[chr]
                if sten not in temp:
                    temp.append(sten)
                    chr_loc_dic[chr]=temp
            else:
                temp=[]
                temp.append(sten)
                chr_loc_dic[chr]=temp


    while 1:
        line=inf1.readline()
        if not line: break
        gs=line.split('\t')
        if line[0]!='#':
            CHR1=gs[0]
            END1=gs[1]
            CHR2=''
            END2=''
            END=''
            SVLEN=0
            SVLEN_=0
            SVTYPE=''
            gss=gs[7].split(';')
            for gg in gss:
                ggs=gg.split('=')
                if ggs[0]=='CHR2':
                    if ggs[1]!=CHR1:
                        CHR2=ggs[1]
                if ggs[0]=='END':
                    END2=ggs[1]
                if ggs[0]=='SVTYPE':
                    SVTYPE=ggs[1]
                if ggs[0]=='SVLEN':
                    rang=re.findall(r'^[0-9]+\-[0-9]+$', ggs[1])
                    if len(rang)!=0:
                        rangs=rang[0].split('-')
                        st=int(rangs[0])
                        en=int(rangs[1])
                        SVLEN_=(st+en)/2

                    else:
                        if ggs[1]!='.':
                            SVLEN_=abs(int(ggs[1]))
            print(SVTYPE)

            if SVTYPE in ['DEL','DUP','INV']:
                print('1')
                if CHR2=='' and SVLEN_>=100000 and CHR1 in chrlist:
                    print('2')
                    SVLEN=SVLEN_
                    g1=''
                    chr1='chr'+CHR1
                    chr2=chr1
                    bp1=int(END1)
                    sten2s=chr_loc_dic[chr1]
                    bp2=int(END2)
                    tss1=0
                    tse1=0
                    tss2=0
                    tse2=0
                    g2=''
                    tss_gap1=0
                    tss_gap2=0
                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2] 
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 < tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten2s[i]]
                    print('g1',g1,'g2',g2)
                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print(T)

            elif SVTYPE in ['CTX', 'CPX', 'BND']:
                print('3')
                if CHR2=='' and SVLEN_>=100000 and CHR1 in chrlist:
                    SVLEN=SVLEN_
                    g1=''
                    chr1='chr'+CHR1
                    chr2=chr1
                    bp1=int(END1)
                    sten2s=chr_loc_dic[chr2]
                    bp2=int(END2)
                    tss1=0
                    tse1=0
                    tss2=0
                    tse2=0
                    g2=''
                    tss_gap1=0
                    tss_gap2=0
                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2] 
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 < tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten2s[i]]
                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print(T)
                if CHR2!='' and CHR1 in chrlist and CHR2 in chrlist:
                    g1=''
                    chr1='chr'+CHR1
                    chr2='chr'+CHR2
                    bp1=int(END1)
                    sten1s=chr_loc_dic[chr1]
                    sten2s=chr_loc_dic[chr2]
                    bp2=int(END2)
                    g2=''
                    for i in range(len(sten1s)):
                        sten2=sten1s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2]
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp1 and bp1 <tse+6:
                            if sten1s[i] in st_en_g_dic:
                                g1=st_en_g_dic[sten1s[i]]

                    for i in range(len(sten2s)):
                        sten2=sten2s[i].split('_')
                        sten2ss = [int(ii) for ii in sten2]
                        tss=sten2ss[0]
                        tse=sten2ss[1]
                        if tss-6<bp2 and bp2 <tse+6:
                            if sten2s[i] in st_en_g_dic:
                                g2=st_en_g_dic[sten2s[i]]
                    if g2!='' and g1!=g2 and g1!='':
                        T=SVTYPE+'\t'+g1+'\t'+chr1+'\t'+str(bp1)+'\t'+g2+'\t'+chr2+'\t'+str(bp2)+'\t'+str(SVLEN)+'\n'
                        print(T)

#vcf_tog(gendir,vcfdir)